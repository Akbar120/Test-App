import streamlit as st
import pandas as pd
import plotly.express as px
import plotly.graph_objects as go
from datetime import datetime, timedelta
from dateutil.relativedelta import relativedelta
from database import init_db, get_db, Product, Sale, PurchaseOrder
from sqlalchemy import func, extract
import io

init_db()

st.set_page_config(page_title="Business Inventory Manager", layout="wide")

st.title("📊 Business Inventory Management System")

menu = st.sidebar.selectbox(
    "Navigation",
    ["Products", "Add Product", "Manage Products", "Record Sale", "Price Comparison", "Monthly Sales Report", "Sales History", "Purchase Orders", "Financial Dashboard", "Trends & Analytics"]
)

def add_product(name, buying_price, selling_price, stock, reorder_level=10, image_url=None):
    db = get_db()
    try:
        product = Product(
            name=name,
            buying_price=buying_price,
            selling_price=selling_price,
            current_stock=stock,
            reorder_level=reorder_level,
            image_url=image_url
        )
        db.add(product)
        db.commit()
        db.refresh(product)
        return True
    except Exception as e:
        db.rollback()
        st.error(f"Error adding product: {e}")
        return False
    finally:
        db.close()

def get_all_products():
    db = get_db()
    try:
        products = db.query(Product).all()
        return products
    finally:
        db.close()

def update_product(product_id, name, buying_price, selling_price, stock, reorder_level=10, image_url=None):
    db = get_db()
    try:
        product = db.query(Product).filter(Product.product_id == product_id).first()
        if product:
            product.name = name
            product.buying_price = buying_price
            product.selling_price = selling_price
            product.current_stock = stock
            product.reorder_level = reorder_level
            product.image_url = image_url
            db.commit()
            return True
        return False
    except Exception as e:
        db.rollback()
        st.error(f"Error updating product: {e}")
        return False
    finally:
        db.close()

def delete_product(product_id):
    db = get_db()
    try:
        product = db.query(Product).filter(Product.product_id == product_id).first()
        if product:
            db.delete(product)
            db.commit()
            return True
        return False
    except Exception as e:
        db.rollback()
        st.error(f"Error deleting product: {e}")
        return False
    finally:
        db.close()

def record_sale(product_id, quantity):
    db = get_db()
    try:
        product = db.query(Product).filter(Product.product_id == product_id).first()
        if not product:
            st.error("Product not found")
            return False
        
        if product.current_stock < quantity:
            st.error(f"Insufficient stock. Available: {product.current_stock}")
            return False
        
        sale = Sale(
            product_id=product_id,
            quantity=quantity,
            sale_price=product.selling_price,
            cost_price=product.buying_price
        )
        
        product.current_stock -= quantity
        
        db.add(sale)
        db.commit()
        return True
    except Exception as e:
        db.rollback()
        st.error(f"Error recording sale: {e}")
        return False
    finally:
        db.close()

def get_monthly_sales(year, month):
    db = get_db()
    try:
        sales = db.query(Sale).filter(
            extract('year', Sale.sale_date) == year,
            extract('month', Sale.sale_date) == month
        ).all()
        return sales
    finally:
        db.close()

def get_monthly_stats(year, month):
    db = get_db()
    try:
        stats = db.query(
            func.sum(Sale.quantity * Sale.sale_price).label('total_revenue'),
            func.sum(Sale.quantity * (Sale.sale_price - Sale.cost_price)).label('total_profit'),
            func.count(Sale.sale_id).label('total_transactions')
        ).filter(
            extract('year', Sale.sale_date) == year,
            extract('month', Sale.sale_date) == month
        ).first()
        
        return {
            'total_revenue': stats.total_revenue or 0,
            'total_profit': stats.total_profit or 0,
            'total_transactions': stats.total_transactions or 0
        }
    finally:
        db.close()

def get_multi_month_stats(months_back=6):
    db = get_db()
    try:
        end_date = datetime.now().replace(day=1)
        start_date = end_date - relativedelta(months=months_back - 1)
        
        monthly_data = []
        current = start_date
        
        for _ in range(months_back):
            stats = db.query(
                func.sum(Sale.quantity * Sale.sale_price).label('total_revenue'),
                func.sum(Sale.quantity * (Sale.sale_price - Sale.cost_price)).label('total_profit'),
                func.count(Sale.sale_id).label('total_transactions')
            ).filter(
                extract('year', Sale.sale_date) == current.year,
                extract('month', Sale.sale_date) == current.month
            ).first()
            
            monthly_data.append({
                'year': current.year,
                'month': current.month,
                'month_name': current.strftime('%b %Y'),
                'revenue': float(stats.total_revenue or 0),
                'profit': float(stats.total_profit or 0),
                'transactions': int(stats.total_transactions or 0)
            })
            
            current = current + relativedelta(months=1)
        
        return monthly_data
    finally:
        db.close()

def get_filtered_sales(start_date=None, end_date=None, product_id=None):
    db = get_db()
    try:
        query = db.query(Sale)
        
        if start_date:
            query = query.filter(Sale.sale_date >= start_date)
        if end_date:
            end_datetime = datetime.combine(end_date, datetime.max.time())
            query = query.filter(Sale.sale_date <= end_datetime)
        if product_id:
            query = query.filter(Sale.product_id == product_id)
        
        sales = query.order_by(Sale.sale_date.desc()).all()
        return sales
    finally:
        db.close()

def export_to_csv(dataframe, filename):
    csv = dataframe.to_csv(index=False)
    return csv

def create_purchase_order(product_id, quantity, expected_delivery, cost_per_unit):
    db = get_db()
    try:
        total_cost = quantity * cost_per_unit
        order = PurchaseOrder(
            product_id=product_id,
            quantity=quantity,
            expected_delivery=expected_delivery,
            cost_per_unit=cost_per_unit,
            total_cost=total_cost,
            status="Pending"
        )
        db.add(order)
        db.commit()
        return True
    except Exception as e:
        db.rollback()
        st.error(f"Error creating purchase order: {e}")
        return False
    finally:
        db.close()

def receive_purchase_order(order_id):
    db = get_db()
    try:
        order = db.query(PurchaseOrder).filter(PurchaseOrder.order_id == order_id).first()
        if order and order.status == "Pending":
            product = db.query(Product).filter(Product.product_id == order.product_id).first()
            if product:
                product.current_stock += order.quantity
                order.status = "Received"
                db.commit()
                return True
        return False
    except Exception as e:
        db.rollback()
        st.error(f"Error receiving purchase order: {e}")
        return False
    finally:
        db.close()

def get_all_purchase_orders():
    db = get_db()
    try:
        orders = db.query(PurchaseOrder).order_by(PurchaseOrder.order_date.desc()).all()
        return orders
    finally:
        db.close()

def cancel_purchase_order(order_id):
    db = get_db()
    try:
        order = db.query(PurchaseOrder).filter(PurchaseOrder.order_id == order_id).first()
        if order and order.status == "Pending":
            order.status = "Cancelled"
            db.commit()
            return True
        return False
    except Exception as e:
        db.rollback()
        st.error(f"Error cancelling purchase order: {e}")
        return False
    finally:
        db.close()

if menu == "Products":
    st.header("📦 Product Catalog")
    
    products = get_all_products()
    
    if products:
        cols = st.columns(3)
        for idx, p in enumerate(products):
            with cols[idx % 3]:
                with st.container():
                    if p.image_url:
                        try:
                            st.image(p.image_url, use_column_width=True)
                        except:
                            st.info("🖼️ No image")
                    else:
                        st.info("🖼️ No image")
                    
                    st.write(f"**{p.name}**")
                    st.write(f"💰 Price: ${p.selling_price:.2f}")
                    st.write(f"📦 Stock: {p.current_stock} units")
                    
                    if p.current_stock <= p.reorder_level:
                        st.warning("⚠️ Low Stock")
        
        st.markdown("---")
        st.subheader("📊 Product List")
        product_data = []
        for p in products:
            product_data.append({
                'ID': p.product_id,
                'Product Name': p.name,
                'Selling Price': f"${p.selling_price:.2f}",
                'Current Stock': p.current_stock
            })
        
        df = pd.DataFrame(product_data)
        st.dataframe(df, use_container_width=True, hide_index=True)
        
        export_df = pd.DataFrame([{
            'ID': p.product_id,
            'Product Name': p.name,
            'Selling Price': p.selling_price,
            'Current Stock': p.current_stock
        } for p in products])
        
        csv = export_to_csv(export_df, "products.csv")
        st.download_button(
            label="📥 Export Products to CSV",
            data=csv,
            file_name=f"products_{datetime.now().strftime('%Y%m%d_%H%M%S')}.csv",
            mime="text/csv"
        )
        
        st.subheader("⚠️ Stock Alerts")
        low_stock = [p for p in products if p.current_stock <= p.reorder_level]
        if low_stock:
            for p in low_stock:
                st.warning(f"**{p.name}** - Only {p.current_stock} units remaining")
        else:
            st.success("All products have adequate stock levels")
    else:
        st.info("No products available. Add your first product using the 'Add Product' menu.")

elif menu == "Manage Products":
    st.header("🔧 Manage Products")
    
    products = get_all_products()
    
    if products:
        st.subheader("📊 Complete Product Information")
        product_data = []
        for p in products:
            product_data.append({
                'ID': p.product_id,
                'Product Name': p.name,
                'Buying Price': f"${p.buying_price:.2f}",
                'Selling Price': f"${p.selling_price:.2f}",
                'Current Stock': p.current_stock,
                'Reorder Level': p.reorder_level,
                'Profit/Unit': f"${(p.selling_price - p.buying_price):.2f}"
            })
        
        df = pd.DataFrame(product_data)
        st.dataframe(df, use_container_width=True, hide_index=True)
        
        st.markdown("---")
        
        col1, col2 = st.columns(2)
        
        with col1:
            st.write("**Edit Product**")
            product_to_edit = st.selectbox(
                "Select Product to Edit",
                options=[(p.product_id, p.name) for p in products],
                format_func=lambda x: x[1]
            )
            
            if product_to_edit:
                selected_product = next((p for p in products if p.product_id == product_to_edit[0]), None)
                if selected_product:
                    with st.form("edit_product_form"):
                        edit_name = st.text_input("Product Name", value=selected_product.name)
                        edit_buying = st.number_input("Buying Price", value=float(selected_product.buying_price), min_value=0.01, step=0.01)
                        edit_selling = st.number_input("Selling Price", value=float(selected_product.selling_price), min_value=0.01, step=0.01)
                        edit_stock = st.number_input("Current Stock", value=int(selected_product.current_stock), min_value=0, step=1)
                        edit_reorder = st.number_input("Reorder Level", value=int(selected_product.reorder_level) if hasattr(selected_product, 'reorder_level') and selected_product.reorder_level else 10, min_value=0, step=1)
                        edit_image_url = st.text_input("Product Image URL (optional)", value=selected_product.image_url if hasattr(selected_product, 'image_url') and selected_product.image_url else "")
                        
                        if edit_image_url:
                            st.image(edit_image_url, width=150, caption="Preview")
                        
                        if st.form_submit_button("Update Product"):
                            if update_product(selected_product.product_id, edit_name, edit_buying, edit_selling, edit_stock, edit_reorder, edit_image_url if edit_image_url else None):
                                st.success("Product updated successfully!")
                                st.rerun()
        
        with col2:
            st.write("**Delete Product**")
            product_to_delete = st.selectbox(
                "Select Product to Delete",
                options=[(p.product_id, p.name) for p in products],
                format_func=lambda x: x[1],
                key="delete_select"
            )
            
            if st.button("Delete Product", type="primary"):
                if delete_product(product_to_delete[0]):
                    st.success("Product deleted successfully!")
                    st.rerun()
        
        st.subheader("⚠️ Reorder Alerts")
        reorder_needed = [p for p in products if p.current_stock <= (p.reorder_level if hasattr(p, 'reorder_level') and p.reorder_level else 10)]
        if reorder_needed:
            for p in reorder_needed:
                reorder_qty = (p.reorder_level if hasattr(p, 'reorder_level') and p.reorder_level else 10) * 2
                st.warning(f"**{p.name}** - Stock: {p.current_stock}, Reorder Level: {p.reorder_level if hasattr(p, 'reorder_level') else 10}. Suggested reorder: {reorder_qty} units")
        else:
            st.success("All products have adequate stock levels")
    else:
        st.info("No products available. Add your first product using the 'Add Product' menu.")

elif menu == "Add Product":
    st.header("➕ Add New Product")
    
    with st.form("add_product_form"):
        name = st.text_input("Product Name")
        col1, col2 = st.columns(2)
        with col1:
            buying_price = st.number_input("Buying Price ($)", min_value=0.01, step=0.01)
        with col2:
            selling_price = st.number_input("Selling Price ($)", min_value=0.01, step=0.01)
        
        col1, col2 = st.columns(2)
        with col1:
            stock = st.number_input("Initial Stock Quantity", min_value=0, step=1)
        with col2:
            reorder_level = st.number_input("Reorder Level", min_value=0, step=1, value=10)
        
        image_url = st.text_input("Product Image URL (optional)", help="Enter a direct link to product image (e.g., https://example.com/image.jpg)")
        
        if image_url:
            try:
                st.image(image_url, width=200, caption="Preview")
            except:
                st.warning("Unable to load image preview. Please check the URL.")
        
        submit = st.form_submit_button("Add Product")
        
        if submit:
            if name and buying_price and selling_price:
                if selling_price >= buying_price:
                    if add_product(name, buying_price, selling_price, stock, reorder_level, image_url if image_url else None):
                        st.success(f"Product '{name}' added successfully!")
                        st.balloons()
                else:
                    st.warning("Selling price should be greater than or equal to buying price for profit!")
            else:
                st.error("Please fill in all required fields")

elif menu == "Record Sale":
    st.header("💰 Record Sale")
    
    products = get_all_products()
    
    if products:
        available_products = [(p.product_id, f"{p.name} (Stock: {p.current_stock}, Price: ${p.selling_price:.2f})") for p in products if p.current_stock > 0]
        
        if available_products:
            with st.form("record_sale_form"):
                selected_product = st.selectbox(
                    "Select Product",
                    options=available_products,
                    format_func=lambda x: x[1]
                )
                
                product = next((p for p in products if p.product_id == selected_product[0]), None)
                
                if product:
                    quantity = st.number_input(
                        f"Quantity (Available: {product.current_stock})",
                        min_value=1,
                        max_value=product.current_stock,
                        step=1
                    )
                    
                    st.info(f"Total Sale Amount: ${product.selling_price * quantity:.2f}")
                    st.info(f"Profit from this sale: ${(product.selling_price - product.buying_price) * quantity:.2f}")
                
                submit = st.form_submit_button("Record Sale")
                
                if submit:
                    if record_sale(selected_product[0], quantity):
                        st.success(f"Sale recorded successfully! {quantity} unit(s) of {product.name} sold.")
                        st.rerun()
        else:
            st.warning("No products available in stock. Please add stock to existing products.")
    else:
        st.info("No products available. Please add products first.")

elif menu == "Price Comparison":
    st.header("💵 Price Comparison Analysis")
    
    products = get_all_products()
    
    if products:
        comparison_data = []
        for p in products:
            profit_per_unit = p.selling_price - p.buying_price
            profit_margin = (profit_per_unit / p.buying_price * 100) if p.buying_price > 0 else 0
            
            comparison_data.append({
                'Product Name': p.name,
                'Buying Price': p.buying_price,
                'Selling Price': p.selling_price,
                'Profit/Unit': profit_per_unit,
                'Profit Margin %': profit_margin,
                'Stock Value (Cost)': p.buying_price * p.current_stock,
                'Stock Value (Retail)': p.selling_price * p.current_stock,
                'Potential Profit': profit_per_unit * p.current_stock
            })
        
        df = pd.DataFrame(comparison_data)
        
        st.subheader("📊 Detailed Price Comparison")
        
        formatted_df = df.copy()
        formatted_df['Buying Price'] = formatted_df['Buying Price'].apply(lambda x: f"${x:.2f}")
        formatted_df['Selling Price'] = formatted_df['Selling Price'].apply(lambda x: f"${x:.2f}")
        formatted_df['Profit/Unit'] = formatted_df['Profit/Unit'].apply(lambda x: f"${x:.2f}")
        formatted_df['Profit Margin %'] = formatted_df['Profit Margin %'].apply(lambda x: f"{x:.2f}%")
        formatted_df['Stock Value (Cost)'] = formatted_df['Stock Value (Cost)'].apply(lambda x: f"${x:.2f}")
        formatted_df['Stock Value (Retail)'] = formatted_df['Stock Value (Retail)'].apply(lambda x: f"${x:.2f}")
        formatted_df['Potential Profit'] = formatted_df['Potential Profit'].apply(lambda x: f"${x:.2f}")
        
        st.dataframe(formatted_df, use_container_width=True, hide_index=True)
        
        col1, col2, col3 = st.columns(3)
        with col1:
            st.metric("Total Stock Value (Cost)", f"${df['Stock Value (Cost)'].sum():.2f}")
        with col2:
            st.metric("Total Stock Value (Retail)", f"${df['Stock Value (Retail)'].sum():.2f}")
        with col3:
            st.metric("Total Potential Profit", f"${df['Potential Profit'].sum():.2f}")
        
        st.subheader("📈 Profit Margin Rankings")
        top_margin = df.nlargest(5, 'Profit Margin %')[['Product Name', 'Profit Margin %']]
        for idx, row in top_margin.iterrows():
            st.success(f"**{row['Product Name']}**: {row['Profit Margin %']:.2f}% margin")
    else:
        st.info("No products available for comparison.")

elif menu == "Monthly Sales Report":
    st.header("📅 Monthly Sales Report")
    
    col1, col2 = st.columns(2)
    with col1:
        selected_month = st.selectbox("Select Month", range(1, 13), index=datetime.now().month - 1, format_func=lambda x: datetime(2000, x, 1).strftime('%B'))
    with col2:
        selected_year = st.number_input("Select Year", min_value=2020, max_value=2030, value=datetime.now().year)
    
    sales = get_monthly_sales(selected_year, selected_month)
    
    if sales:
        sales_data = []
        export_monthly_data = []
        db = get_db()
        try:
            for sale in sales:
                product = db.query(Product).filter(Product.product_id == sale.product_id).first()
                product_name = product.name if product else "Unknown"
                
                revenue = sale.quantity * sale.sale_price
                profit = sale.quantity * (sale.sale_price - sale.cost_price)
                
                sales_data.append({
                    'Date': sale.sale_date.strftime('%Y-%m-%d %H:%M'),
                    'Product': product_name,
                    'Quantity': sale.quantity,
                    'Unit Price': f"${sale.sale_price:.2f}",
                    'Revenue': f"${revenue:.2f}",
                    'Profit': f"${profit:.2f}"
                })
                
                export_monthly_data.append({
                    'Date': sale.sale_date.strftime('%Y-%m-%d %H:%M'),
                    'Product': product_name,
                    'Quantity': sale.quantity,
                    'Unit Price': sale.sale_price,
                    'Revenue': revenue,
                    'Profit': profit
                })
        finally:
            db.close()
        
        df = pd.DataFrame(sales_data)
        st.dataframe(df, use_container_width=True, hide_index=True)
        
        export_monthly_df = pd.DataFrame(export_monthly_data)
        
        csv_monthly = export_to_csv(export_monthly_df, "monthly_sales.csv")
        st.download_button(
            label="📥 Export Monthly Report to CSV",
            data=csv_monthly,
            file_name=f"monthly_sales_{datetime(2000, selected_month, 1).strftime('%B')}_{selected_year}.csv",
            mime="text/csv"
        )
        
        st.subheader("📊 Monthly Summary")
        stats = get_monthly_stats(selected_year, selected_month)
        
        col1, col2, col3 = st.columns(3)
        with col1:
            st.metric("Total Revenue", f"${stats['total_revenue']:.2f}")
        with col2:
            st.metric("Total Profit", f"${stats['total_profit']:.2f}")
        with col3:
            st.metric("Total Transactions", stats['total_transactions'])
        
        if stats['total_revenue'] > 0:
            profit_percentage = (stats['total_profit'] / stats['total_revenue']) * 100
            st.info(f"Overall Profit Margin: {profit_percentage:.2f}%")
    else:
        st.info(f"No sales recorded for {datetime(2000, selected_month, 1).strftime('%B')} {selected_year}")

elif menu == "Sales History":
    st.header("📜 Detailed Sales History")
    
    st.subheader("🔍 Filter Options")
    
    col1, col2, col3 = st.columns(3)
    
    with col1:
        start_date = st.date_input(
            "Start Date",
            value=datetime.now() - timedelta(days=30),
            max_value=datetime.now()
        )
    
    with col2:
        end_date = st.date_input(
            "End Date",
            value=datetime.now(),
            max_value=datetime.now()
        )
    
    with col3:
        products = get_all_products()
        product_options = [("all", "All Products")] + [(p.product_id, p.name) for p in products]
        selected_product = st.selectbox(
            "Select Product",
            options=product_options,
            format_func=lambda x: x[1]
        )
    
    product_filter = None if selected_product[0] == "all" else selected_product[0]
    
    if st.button("Apply Filters", type="primary"):
        st.session_state.filter_applied = True
    
    if 'filter_applied' not in st.session_state:
        st.session_state.filter_applied = True
    
    if st.session_state.filter_applied:
        sales = get_filtered_sales(
            start_date=datetime.combine(start_date, datetime.min.time()),
            end_date=end_date,
            product_id=product_filter
        )
        
        if sales:
            sales_data = []
            total_revenue = 0
            total_profit = 0
            total_quantity = 0
            
            db = get_db()
            try:
                for sale in sales:
                    product = db.query(Product).filter(Product.product_id == sale.product_id).first()
                    product_name = product.name if product else "Unknown"
                    
                    revenue = sale.quantity * sale.sale_price
                    profit = sale.quantity * (sale.sale_price - sale.cost_price)
                    
                    total_revenue += revenue
                    total_profit += profit
                    total_quantity += sale.quantity
                    
                    sales_data.append({
                        'Sale ID': sale.sale_id,
                        'Date & Time': sale.sale_date.strftime('%Y-%m-%d %H:%M:%S'),
                        'Product': product_name,
                        'Quantity': sale.quantity,
                        'Unit Price': f"${sale.sale_price:.2f}",
                        'Cost Price': f"${sale.cost_price:.2f}",
                        'Revenue': f"${revenue:.2f}",
                        'Profit': f"${profit:.2f}"
                    })
            finally:
                db.close()
            
            st.subheader("📊 Sales Records")
            df = pd.DataFrame(sales_data)
            st.dataframe(df, use_container_width=True, hide_index=True)
            
            db_export = get_db()
            try:
                export_sales_data = []
                for sale in sales:
                    product = db_export.query(Product).filter(Product.product_id == sale.product_id).first()
                    product_name = product.name if product else "Unknown"
                    export_sales_data.append({
                        'Sale ID': sale.sale_id,
                        'Date & Time': sale.sale_date.strftime('%Y-%m-%d %H:%M:%S'),
                        'Product ID': sale.product_id,
                        'Product': product_name,
                        'Quantity': sale.quantity,
                        'Unit Price': sale.sale_price,
                        'Cost Price': sale.cost_price,
                        'Revenue': sale.quantity * sale.sale_price,
                        'Profit': sale.quantity * (sale.sale_price - sale.cost_price)
                    })
                export_sales_df = pd.DataFrame(export_sales_data)
            finally:
                db_export.close()
            
            csv_sales = export_to_csv(export_sales_df, "sales_history.csv")
            st.download_button(
                label="📥 Export Sales History to CSV",
                data=csv_sales,
                file_name=f"sales_history_{start_date.strftime('%Y%m%d')}_to_{end_date.strftime('%Y%m%d')}.csv",
                mime="text/csv"
            )
            
            st.subheader("📈 Summary Statistics")
            col1, col2, col3, col4 = st.columns(4)
            
            with col1:
                st.metric("Total Sales", len(sales))
            with col2:
                st.metric("Total Items Sold", total_quantity)
            with col3:
                st.metric("Total Revenue", f"${total_revenue:.2f}")
            with col4:
                st.metric("Total Profit", f"${total_profit:.2f}")
            
            if total_revenue > 0:
                profit_margin = (total_profit / total_revenue) * 100
                st.info(f"📊 Average Profit Margin: {profit_margin:.2f}%")
            
            db = get_db()
            try:
                product_breakdown = db.query(
                    Product.name,
                    func.sum(Sale.quantity).label('total_quantity'),
                    func.sum(Sale.quantity * Sale.sale_price).label('total_revenue'),
                    func.sum(Sale.quantity * (Sale.sale_price - Sale.cost_price)).label('total_profit')
                ).join(Sale).filter(
                    Sale.sale_date >= datetime.combine(start_date, datetime.min.time()),
                    Sale.sale_date <= datetime.combine(end_date, datetime.max.time())
                )
                
                if product_filter:
                    product_breakdown = product_breakdown.filter(Sale.product_id == product_filter)
                
                product_breakdown = product_breakdown.group_by(Product.name).all()
                
                if product_breakdown and len(product_breakdown) > 1:
                    st.subheader("🏆 Product Performance Breakdown")
                    
                    breakdown_data = []
                    for name, qty, rev, prof in product_breakdown:
                        breakdown_data.append({
                            'Product': name,
                            'Units Sold': qty,
                            'Revenue': f"${rev:.2f}",
                            'Profit': f"${prof:.2f}"
                        })
                    
                    breakdown_df = pd.DataFrame(breakdown_data)
                    st.dataframe(breakdown_df, use_container_width=True, hide_index=True)
            finally:
                db.close()
        else:
            st.info("No sales found for the selected filters.")

elif menu == "Purchase Orders":
    st.header("📦 Purchase Order Management")
    
    tab1, tab2 = st.tabs(["Create Purchase Order", "View Purchase Orders"])
    
    with tab1:
        st.subheader("➕ Create New Purchase Order")
        
        products = get_all_products()
        if products:
            with st.form("create_po_form"):
                product_options = [(p.product_id, f"{p.name} (Current Stock: {p.current_stock})") for p in products]
                selected_product = st.selectbox(
                    "Select Product",
                    options=product_options,
                    format_func=lambda x: x[1]
                )
                
                product = next((p for p in products if p.product_id == selected_product[0]), None)
                
                if product:
                    st.info(f"Current Stock: {product.current_stock} | Reorder Level: {product.reorder_level}")
                    if product.current_stock <= product.reorder_level:
                        st.warning(f"⚠️ This product needs restocking!")
                
                col1, col2 = st.columns(2)
                with col1:
                    quantity = st.number_input("Order Quantity", min_value=1, step=1, value=50)
                with col2:
                    cost_per_unit = st.number_input("Cost Per Unit ($)", min_value=0.01, step=0.01, value=float(product.buying_price) if product else 0.01)
                
                expected_delivery = st.date_input(
                    "Expected Delivery Date",
                    value=datetime.now() + timedelta(days=7),
                    min_value=datetime.now()
                )
                
                total_cost = quantity * cost_per_unit
                st.info(f"Total Order Cost: ${total_cost:.2f}")
                
                submit = st.form_submit_button("Create Purchase Order")
                
                if submit:
                    if create_purchase_order(selected_product[0], quantity, datetime.combine(expected_delivery, datetime.min.time()), cost_per_unit):
                        st.success(f"Purchase order created successfully!")
                        st.balloons()
                        st.rerun()
        else:
            st.info("No products available. Add products first before creating purchase orders.")
    
    with tab2:
        st.subheader("📋 All Purchase Orders")
        
        orders = get_all_purchase_orders()
        
        if orders:
            col1, col2, col3 = st.columns(3)
            with col1:
                pending_orders = [o for o in orders if o.status == "Pending"]
                st.metric("Pending Orders", len(pending_orders))
            with col2:
                received_orders = [o for o in orders if o.status == "Received"]
                st.metric("Received Orders", len(received_orders))
            with col3:
                cancelled_orders = [o for o in orders if o.status == "Cancelled"]
                st.metric("Cancelled Orders", len(cancelled_orders))
            
            status_filter = st.selectbox("Filter by Status", ["All", "Pending", "Received", "Cancelled"])
            
            filtered_orders = orders if status_filter == "All" else [o for o in orders if o.status == status_filter]
            
            if filtered_orders:
                order_data = []
                db = get_db()
                try:
                    for order in filtered_orders:
                        product = db.query(Product).filter(Product.product_id == order.product_id).first()
                        product_name = product.name if product else "Unknown"
                        
                        order_data.append({
                            'Order ID': order.order_id,
                            'Product': product_name,
                            'Quantity': order.quantity,
                            'Cost/Unit': f"${order.cost_per_unit:.2f}",
                            'Total Cost': f"${order.total_cost:.2f}",
                            'Order Date': order.order_date.strftime('%Y-%m-%d'),
                            'Expected Delivery': order.expected_delivery.strftime('%Y-%m-%d') if order.expected_delivery else "N/A",
                            'Status': order.status
                        })
                finally:
                    db.close()
                
                df = pd.DataFrame(order_data)
                st.dataframe(df, use_container_width=True, hide_index=True)
                
                st.subheader("🔧 Manage Orders")
                
                pending_orders_list = [o for o in filtered_orders if o.status == "Pending"]
                if pending_orders_list:
                    col1, col2 = st.columns(2)
                    
                    with col1:
                        st.write("**Receive Order**")
                        order_to_receive = st.selectbox(
                            "Select Order to Receive",
                            options=[(o.order_id, f"Order #{o.order_id}") for o in pending_orders_list],
                            format_func=lambda x: x[1]
                        )
                        
                        if st.button("Mark as Received", type="primary"):
                            if receive_purchase_order(order_to_receive[0]):
                                st.success("Order received and stock updated!")
                                st.rerun()
                    
                    with col2:
                        st.write("**Cancel Order**")
                        order_to_cancel = st.selectbox(
                            "Select Order to Cancel",
                            options=[(o.order_id, f"Order #{o.order_id}") for o in pending_orders_list],
                            format_func=lambda x: x[1],
                            key="cancel_select"
                        )
                        
                        if st.button("Cancel Order", type="secondary"):
                            if cancel_purchase_order(order_to_cancel[0]):
                                st.success("Order cancelled successfully!")
                                st.rerun()
                else:
                    st.info("No pending orders to manage.")
            else:
                st.info(f"No {status_filter.lower()} orders found.")
        else:
            st.info("No purchase orders created yet.")

elif menu == "Financial Dashboard":
    st.header("💼 Financial Dashboard")
    
    current_month = datetime.now().month
    current_year = datetime.now().year
    
    st.subheader(f"Current Month: {datetime.now().strftime('%B %Y')}")
    
    current_stats = get_monthly_stats(current_year, current_month)
    
    col1, col2, col3, col4 = st.columns(4)
    
    with col1:
        st.metric("Monthly Revenue", f"${current_stats['total_revenue']:.2f}")
    with col2:
        st.metric("Monthly Profit", f"${current_stats['total_profit']:.2f}")
    with col3:
        st.metric("Transactions", current_stats['total_transactions'])
    with col4:
        if current_stats['total_revenue'] > 0:
            margin = (current_stats['total_profit'] / current_stats['total_revenue']) * 100
            st.metric("Profit Margin", f"{margin:.2f}%")
        else:
            st.metric("Profit Margin", "0.00%")
    
    products = get_all_products()
    if products:
        st.subheader("📦 Current Inventory Overview")
        
        total_stock_value_cost = sum(p.buying_price * p.current_stock for p in products)
        total_stock_value_retail = sum(p.selling_price * p.current_stock for p in products)
        potential_profit = total_stock_value_retail - total_stock_value_cost
        
        col1, col2, col3 = st.columns(3)
        with col1:
            st.metric("Inventory Value (Cost)", f"${total_stock_value_cost:.2f}")
        with col2:
            st.metric("Inventory Value (Retail)", f"${total_stock_value_retail:.2f}")
        with col3:
            st.metric("Potential Profit in Stock", f"${potential_profit:.2f}")
        
        st.subheader("📊 Performance Analysis")
        
        if current_stats['total_profit'] > 0:
            st.success(f"✅ Profitable Month: ${current_stats['total_profit']:.2f} profit")
        elif current_stats['total_profit'] < 0:
            st.error(f"❌ Loss Month: ${abs(current_stats['total_profit']):.2f} loss")
        else:
            st.info("No profit or loss this month")
        
        db = get_db()
        try:
            top_products = db.query(
                Product.name,
                func.sum(Sale.quantity).label('total_sold'),
                func.sum(Sale.quantity * (Sale.sale_price - Sale.cost_price)).label('product_profit')
            ).join(Sale).filter(
                extract('year', Sale.sale_date) == current_year,
                extract('month', Sale.sale_date) == current_month
            ).group_by(Product.name).order_by(func.sum(Sale.quantity * (Sale.sale_price - Sale.cost_price)).desc()).limit(5).all()
            
            if top_products:
                st.subheader("🏆 Top Performing Products This Month")
                for idx, (name, sold, profit) in enumerate(top_products, 1):
                    st.write(f"{idx}. **{name}** - {sold} units sold, ${profit:.2f} profit")
        finally:
            db.close()
    else:
        st.info("No inventory data available.")

elif menu == "Trends & Analytics":
    st.header("📈 Trends & Analytics")
    
    st.subheader("Multi-Month Performance Comparison")
    
    months_options = {"3 Months": 3, "6 Months": 6, "12 Months": 12, "24 Months": 24}
    selected_period = st.selectbox("Select Period", list(months_options.keys()), index=1)
    
    months_back = months_options[selected_period]
    trend_data = get_multi_month_stats(months_back)
    
    if any(d['revenue'] > 0 or d['profit'] > 0 for d in trend_data):
        df_trends = pd.DataFrame(trend_data)
        
        col1, col2 = st.columns(2)
        
        with col1:
            st.subheader("💰 Revenue Trend")
            fig_revenue = go.Figure()
            fig_revenue.add_trace(go.Scatter(
                x=df_trends['month_name'],
                y=df_trends['revenue'],
                mode='lines+markers',
                name='Revenue',
                line=dict(color='#1f77b4', width=3),
                marker=dict(size=8),
                fill='tozeroy',
                fillcolor='rgba(31, 119, 180, 0.2)'
            ))
            fig_revenue.update_layout(
                xaxis_title="Month",
                yaxis_title="Revenue ($)",
                hovermode='x unified',
                height=400
            )
            st.plotly_chart(fig_revenue, use_container_width=True)
        
        with col2:
            st.subheader("💵 Profit Trend")
            fig_profit = go.Figure()
            fig_profit.add_trace(go.Scatter(
                x=df_trends['month_name'],
                y=df_trends['profit'],
                mode='lines+markers',
                name='Profit',
                line=dict(color='#2ca02c', width=3),
                marker=dict(size=8),
                fill='tozeroy',
                fillcolor='rgba(44, 160, 44, 0.2)'
            ))
            fig_profit.update_layout(
                xaxis_title="Month",
                yaxis_title="Profit ($)",
                hovermode='x unified',
                height=400
            )
            st.plotly_chart(fig_profit, use_container_width=True)
        
        st.subheader("📊 Combined Revenue vs Profit")
        fig_combined = go.Figure()
        fig_combined.add_trace(go.Bar(
            x=df_trends['month_name'],
            y=df_trends['revenue'],
            name='Revenue',
            marker_color='#1f77b4'
        ))
        fig_combined.add_trace(go.Bar(
            x=df_trends['month_name'],
            y=df_trends['profit'],
            name='Profit',
            marker_color='#2ca02c'
        ))
        fig_combined.update_layout(
            xaxis_title="Month",
            yaxis_title="Amount ($)",
            barmode='group',
            hovermode='x unified',
            height=400
        )
        st.plotly_chart(fig_combined, use_container_width=True)
        
        st.subheader("📉 Profit Margin Trend")
        df_trends['profit_margin'] = df_trends.apply(
            lambda x: (x['profit'] / x['revenue'] * 100) if x['revenue'] > 0 else 0,
            axis=1
        )
        
        fig_margin = go.Figure()
        fig_margin.add_trace(go.Scatter(
            x=df_trends['month_name'],
            y=df_trends['profit_margin'],
            mode='lines+markers',
            name='Profit Margin %',
            line=dict(color='#ff7f0e', width=3),
            marker=dict(size=8)
        ))
        fig_margin.update_layout(
            xaxis_title="Month",
            yaxis_title="Profit Margin (%)",
            hovermode='x unified',
            height=400
        )
        st.plotly_chart(fig_margin, use_container_width=True)
        
        st.subheader("📈 Key Insights")
        col1, col2, col3, col4 = st.columns(4)
        
        total_revenue = df_trends['revenue'].sum()
        total_profit = df_trends['profit'].sum()
        avg_monthly_revenue = df_trends['revenue'].mean()
        avg_monthly_profit = df_trends['profit'].mean()
        
        with col1:
            st.metric("Total Revenue", f"${total_revenue:.2f}")
        with col2:
            st.metric("Total Profit", f"${total_profit:.2f}")
        with col3:
            st.metric("Avg Monthly Revenue", f"${avg_monthly_revenue:.2f}")
        with col4:
            st.metric("Avg Monthly Profit", f"${avg_monthly_profit:.2f}")
        
        best_month = df_trends.loc[df_trends['profit'].idxmax()]
        worst_month = df_trends.loc[df_trends['profit'].idxmin()]
        
        col1, col2 = st.columns(2)
        with col1:
            st.success(f"🏆 **Best Month**: {best_month['month_name']} with ${best_month['profit']:.2f} profit")
        with col2:
            if worst_month['profit'] < 0:
                st.error(f"⚠️ **Worst Month**: {worst_month['month_name']} with ${abs(worst_month['profit']):.2f} loss")
            else:
                st.info(f"📊 **Lowest Month**: {worst_month['month_name']} with ${worst_month['profit']:.2f} profit")
    else:
        st.info("No sales data available for the selected period. Start recording sales to see trends!")

st.sidebar.markdown("---")
st.sidebar.info("💡 **Tip**: Keep your product information updated for accurate financial tracking!")
